package pkgfinal.project;

import java.util.ArrayList;
import javafx.scene.control.RadioButton;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;


public class LinePane extends Pane{
    
    private ArrayList <RadioButton> buttonList; 
    private ArrayList <Line> lineList; 
    
    
    
    public LinePane() {
    double xindex = 8; 
    int yindex = 0; 
   
    lineList = new ArrayList<Line>(); 
    buttonList = new ArrayList<RadioButton>();
    
            while (xindex < 550) {

            while (yindex < 550) {
                Line line = new Line();
                line.setStartX(xindex);
                line.setStartY(yindex);
                line.setEndX(xindex);
                line.setEndY(yindex+50);
                line.setStrokeWidth(2);
                line.setFill(Color.BLACK);
                lineList.add(line);
                
                Line line2 = new Line();
                line2.setStartX(xindex);
                line2.setStartY(yindex+8);
                line2.setEndX(xindex+50);
                line2.setEndY(yindex+8);
                line2.setStrokeWidth(2);
                line2.setFill(Color.BLACK);
                lineList.add(line2);                
                
                yindex = yindex + 50;

            }
            
            xindex = xindex + 50;
            yindex = 0;
        }

        for (Line thisline : lineList) {
            getChildren().add(thisline);
        }
        
    xindex = 0;
    yindex = 0; 
    while (xindex < 550){
        
        while(yindex < 550){
          RadioButton button = new RadioButton();
          button.setTranslateX(xindex);
          
          button.setTranslateY(yindex);
          buttonList.add(button);
          yindex = yindex + 50;
          
        }
        xindex = xindex+50;
        yindex = 0; 
    } 
    
    for (RadioButton thisbutton : buttonList)  
    {
       getChildren().add(thisbutton);
    }
    
    

    

    
        
    }
    
    
    
    
}
